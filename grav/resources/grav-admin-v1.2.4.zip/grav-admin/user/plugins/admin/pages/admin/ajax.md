---
title: Generic Ajax
template: default

access:
    admin.login: true
---
